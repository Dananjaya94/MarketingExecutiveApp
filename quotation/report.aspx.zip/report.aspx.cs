﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Data.SqlClient;
using System.Configuration;

public partial class report : System.Web.UI.Page
{
    DataTable dt = null;
    ArrayList init_values;
    ArrayList init_perils;

    string totalPerilAmt;

    protected void Page_Load(object sender, EventArgs e)
    {

        ClearTables();

        if (ViewState["Details"] == null)
        {
            DataTable datatable = new DataTable();
            datatable.Columns.Add("Peril Description");
            datatable.Columns.Add("Value");
            ViewState["Details"] = datatable;
        }


        string product=Session["product"].ToString();
        string productType = Session["productType"].ToString();
        string sumIns = Session["sumins"].ToString();
        string name = Session["name"].ToString();
        string vehicle = Session["vno"].ToString();

        totalPerilAmt = Session["totalPerilAmt"].ToString();
        //string premium = Session["premium"].ToString();
        string polfee = Session["polfee"].ToString();
        string nbl = Session["nbl"].ToString();
        string adminf = Session["adminf"].ToString();
        string vat = Session["vat"].ToString();
        string finaltot = Session["finaltot"].ToString();

        init_values = (ArrayList)Session["perilnames"];
        init_perils = (ArrayList)Session["perilvalues"];

        LabelName.Text      = name;
        LabelProduct.Text   = product;
        LabelPType.Text     = productType;
        LabelVehicle.Text   = vehicle;

        LabelpolicyFee.Text = polfee;
        LabelVat.Text       = vat;
        LabelAdminFee.Text  = adminf;
        LabelNBT.Text       = nbl;

        //LabelPerilTotal.Text = totalPerilAmt;
        LabelTotal.Text = finaltot;

        FillPerils();
    }

    private void ClearTables()
    {
        ViewState["Details"] = null;
        GridViewDetails.DataSource = null;
        GridViewDetails.DataBind();
    }

    private void FillPerils()
    {
        dt = (DataTable)ViewState["Details"];

        for (int j = 0; j < init_values.Count; j++)
        {
            dt.Rows.Add(init_perils[j].ToString(), init_values[j].ToString());
        }
        
        ViewState["Details"] = dt;
        GridViewDetails.DataSource = dt;       
        GridViewDetails.DataBind();

        //BorderStyle="Solid" GridLines="Both"

        //GridViewDetails.GridLines="Both";
        GridViewDetails.FooterRow.Cells[0].Text = "Peril Total";
        GridViewDetails.FooterRow.Cells[0].HorizontalAlign = HorizontalAlign.Right;
        GridViewDetails.FooterRow.Cells[0].Font.Bold = true;
        GridViewDetails.FooterRow.Cells[1].Text = totalPerilAmt;
        GridViewDetails.FooterRow.Cells[1].HorizontalAlign = HorizontalAlign.Right;
        GridViewDetails.FooterRow.Cells[1].Font.Bold = true;
    }
    protected void GridViewDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        
            int i = ((DataTable)((GridView)sender).DataSource).Columns.IndexOf("Value");
            for (int j = 0; j < e.Row.Cells.Count; j++)
            {

                if (j == i)
                    e.Row.Cells[j].HorizontalAlign = HorizontalAlign.Right;
                else
                    e.Row.Cells[j].HorizontalAlign = HorizontalAlign.Left;
            }
        }
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Employee.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        StringWriter stringWriter = new StringWriter();
        HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
        employeelistDiv.RenderControl(htmlTextWriter);

        StringReader stringReader = new StringReader(stringWriter.ToString());
        Document Doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(Doc);
        PdfWriter.GetInstance(Doc, Response.OutputStream);

        Doc.Open();
        htmlparser.Parse(stringReader);
        Doc.Close();
        Response.Write(Doc);
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }
}