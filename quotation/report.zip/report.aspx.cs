﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;

public partial class report : System.Web.UI.Page
{
    DataTable dt = null;
    ArrayList init_values;
    ArrayList init_perils;

    Connection db;
    OracleConnection con;
    OracleCommand cmd;
    OracleDataReader rd;

    string totalPerilAmt;

    protected void Page_Load(object sender, EventArgs e)
    {

        ClearTables();

        if (ViewState["Details"] == null)
        {
            TextBoxUser.Text = HttpUtility.UrlDecode(Request.QueryString["user"]).Trim().ToUpper().ToString();
            getUserDtl();
            DataTable datatable = new DataTable();
            datatable.Columns.Add("Peril Description");
            datatable.Columns.Add("Value");
            ViewState["Details"] = datatable;
        }


        string product=Session["product"].ToString();
        string productType = Session["productType"].ToString();
        string sumIns = Session["sumins"].ToString();
        string name = Session["name"].ToString();
        string vehicle = Session["vno"].ToString();

        totalPerilAmt = Session["totalPerilAmt"].ToString();
        //string premium = Session["premium"].ToString();
        string polfee = Session["polfee"].ToString();
        string nbl = Session["nbl"].ToString();
        string adminf = Session["adminf"].ToString();
        string vat = Session["vat"].ToString();
        string finaltot = Session["finaltot"].ToString();

        init_values = (ArrayList)Session["perilnames"];
        init_perils = (ArrayList)Session["perilvalues"];

        LabelName.Text      = name;
        LabelProduct.Text   = product;
        LabelPType.Text     = productType;
        LabelVehicle.Text   = vehicle;

        LabelpolicyFee.Text = polfee;
        LabelVat.Text       = vat;
        LabelAdminFee.Text  = adminf;
        LabelNBT.Text       = nbl;

        //LabelPerilTotal.Text = totalPerilAmt;
        LabelTotal.Text = finaltot;

        FillPerils();
    }

    private void ClearTables()
    {
        ViewState["Details"] = null;
        GridViewDetails.DataSource = null;
        GridViewDetails.DataBind();
    }

    private void FillPerils()
    {
        dt = (DataTable)ViewState["Details"];

        for (int j = 0; j < init_values.Count; j++)
        {
            dt.Rows.Add(init_perils[j].ToString(), init_values[j].ToString());
        }
        
        ViewState["Details"] = dt;
        GridViewDetails.DataSource = dt;       
        GridViewDetails.DataBind();

        //BorderStyle="Solid" GridLines="Both"

        //GridViewDetails.GridLines="Both";
        GridViewDetails.FooterRow.Cells[0].Text = "Peril Total";
        GridViewDetails.FooterRow.Cells[0].HorizontalAlign = HorizontalAlign.Right;
        GridViewDetails.FooterRow.Cells[0].Font.Bold = true;
        GridViewDetails.FooterRow.Cells[1].Text = totalPerilAmt;
        GridViewDetails.FooterRow.Cells[1].HorizontalAlign = HorizontalAlign.Right;
        GridViewDetails.FooterRow.Cells[1].Font.Bold = true;
    }
    protected void GridViewDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
        
            int i = ((DataTable)((GridView)sender).DataSource).Columns.IndexOf("Value");
            for (int j = 0; j < e.Row.Cells.Count; j++)
            {

                if (j == i)
                    e.Row.Cells[j].HorizontalAlign = HorizontalAlign.Right;
                else
                    e.Row.Cells[j].HorizontalAlign = HorizontalAlign.Left;
            }
        }
    }
    /*
     * This method must override before export to an excel
     * */
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    public void getUserDtl()
    {
        String epf = TextBoxUser.Text;

        string sq = "select (REPLACE(a.sfc_first_name, '.', '')||' '||a.sfc_surname)full_name,a.sfc_mobile1 from sm_m_sales_force a where sfc_code='" + epf + "'";

        try
        {
            db = new Connection();
            con = db.GetConnection;
            con.Open();
            OracleCommand cmd1 = new OracleCommand(sq, con);
            OracleDataReader rd1 = cmd1.ExecuteReader();

            //if (rd1.HasRows)
            //{
            while (rd1.Read())
            {

                Label3.Text = "Please note that this is only a system generated premium indication and if you need a quotation with further details contact " + rd1[0] + " on " + rd1[1] + " or nearest Ceylinco General Insurance LTD.";
           
            }
            //}
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            con.Close();
        }

        
    }
    

    //protected void ButtonPdf_Click(object sender, EventArgs e)
    //{
    //    using (StringWriter sw = new StringWriter())
    //    {
    //        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
    //        {

    //            Table1.RenderControl(hw);
    //            //GridViewDetails.RenderControl(hw);
    //            Table2.RenderControl(hw);
    //            Table3.RenderControl(hw);

    //            StringReader sr = new StringReader(sw.ToString());
    //            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
    //            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
    //            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
    //            pdfDoc.Open();
    //            htmlparser.Parse(sr);
    //            pdfDoc.Close();

    //            Response.ContentType = "application/pdf";

    //            //get date for file save
    //            string sys_date = System.DateTime.Today.ToLongDateString();
    //            Response.AddHeader("content-disposition", "attachment;filename=quotation '" + sys_date + "'.pdf");

    //            Response.Cache.SetCacheability(HttpCacheability.NoCache);
    //            Response.Write(pdfDoc);
    //            Response.End();
    //        }
    //    }
    //}
}